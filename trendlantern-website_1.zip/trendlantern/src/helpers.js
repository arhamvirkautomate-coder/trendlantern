// ------------------------------------------------------------ formatting
const rate = () => (S.snap?.fx?.[S.cur]) || 1;
function fp(usd, cur=S.cur){
  if (usd == null || !isFinite(usd)) return "—";
  const v = usd * ((S.snap?.fx?.[cur]) || 1), a = Math.abs(v);
  let s;
  if (a >= 1000) s = v.toLocaleString("en-US",{maximumFractionDigits: a>=100000?0:2});
  else if (a >= 1) s = v.toLocaleString("en-US",{maximumFractionDigits:4});
  else if (a === 0) s = "0";
  else s = Number(v.toPrecision(4)).toString();
  return (CUR[cur]?.s||"") + s;
}
function fb(usd){
  if (usd == null || !isFinite(usd)) return "—";
  const v = usd * rate(), a = Math.abs(v);
  const [d,u] = a>=1e12?[1e12,"T"]:a>=1e9?[1e9,"B"]:a>=1e6?[1e6,"M"]:a>=1e3?[1e3,"K"]:[1,""];
  return CUR[S.cur].s + (v/d).toFixed(a>=1e3?2:0) + u;
}
function fm(usd){ // money amounts (sizes, P&L)
  if (usd == null || !isFinite(usd)) return "—";
  const v = usd * rate();
  return (v<0?"−":"") + CUR[S.cur].s + Math.abs(v).toLocaleString("en-US",{maximumFractionDigits: Math.abs(v)>=1000?0:2, minimumFractionDigits: Math.abs(v)>=1000?0:2});
}
const fpct = (x, d=2) => x == null || !isFinite(x) ? "—" : (x>0?"+":x<0?"−":"") + Math.abs(x).toFixed(d) + "%";
const cls = x => x > 0 ? "up" : x < 0 ? "down" : "";
const lblCls = l => ({"Strong uptrend":"sb","Uptrend":"b","Neutral":"h","Weakening":"r","Downtrend":"s"})[l] || "h";
const ago = ms => { if(!ms) return "—"; const m = Math.round((Date.now()-ms)/60000); return m<1?"just now":m<60?m+" min ago":m<1440?Math.round(m/60)+" h ago":Math.round(m/1440)+" d ago"; };
const dt = ms => ms ? new Date(ms).toLocaleString(undefined,{month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"}) : "—";
const coin = sym => S.snap?.coins?.find(c => c.sym === sym);
const pill = (label, extra) => h("span",{class:"pill "+lblCls(label)+(extra?" "+extra:"")}, label);
const riskPill = r => h("span",{class:"pill risk-"+r}, r+" risk");

// ------------------------------------------------------------ charts (SVG)
const NS = "http://www.w3.org/2000/svg";
function s(tag, attrs){ const el = document.createElementNS(NS, tag); for (const [k,v] of Object.entries(attrs||{})) el.setAttribute(k, v); return el; }
function spark(vals, w=96, hgt=28){
  const svg = s("svg",{viewBox:`0 0 ${w} ${hgt}`,width:w,height:hgt,"aria-hidden":"true"});
  if (!vals || vals.length < 2) return svg;
  const mn = Math.min(...vals), mx = Math.max(...vals), r = mx-mn || 1;
  const pts = vals.map((v,i)=>[i/(vals.length-1)*(w-4)+2, hgt-3-(v-mn)/r*(hgt-6)]);
  const col = vals[vals.length-1] >= vals[0] ? "var(--up)" : "var(--down)";
  svg.append(s("polyline",{points:pts.map(p=>p.join(",")).join(" "),fill:"none",stroke:col,"stroke-width":1.5,"stroke-linejoin":"round"}));
  const e = pts[pts.length-1]; svg.append(s("circle",{cx:e[0],cy:e[1],r:2,fill:col}));
  return svg;
}
function lineChart(vals, {w=640, hgt=220, overlays=[], fmt=v=>fp(v), t0=null, step=null, color="var(--chart)", fill="var(--chart-fill)", yMin=null, yMax=null}={}){
  const svg = s("svg",{viewBox:`0 0 ${w} ${hgt}`,role:"img"});
  if (!vals || vals.length < 2){ const t = s("text",{x:w/2,y:hgt/2,"text-anchor":"middle"}); t.textContent="No chart data yet"; svg.append(t); return svg; }
  const L=8, R=78, T=10, B=22;
  const ov = overlays.map(o=>o.v).filter(v=>v!=null && isFinite(v));
  let mn = yMin ?? Math.min(...vals, ...ov), mx = yMax ?? Math.max(...vals, ...ov);
  const pad = (mx-mn)*0.06 || mx*0.02 || 1; if (yMin==null) mn -= pad; if (yMax==null) mx += pad;
  const X = i => L + i/(vals.length-1)*(w-L-R), Y = v => T + (1-(v-mn)/(mx-mn))*(hgt-T-B);
  for (let g=0; g<=4; g++){
    const v = mn + (mx-mn)*g/4, y = Y(v);
    svg.append(s("line",{x1:L,x2:w-R,y1:y,y2:y,stroke:"var(--line)","stroke-width":1}));
    const t = s("text",{x:w-R+6,y:y+3}); t.textContent = fmt(v); svg.append(t);
  }
  if (t0 && step){
    [0, Math.floor((vals.length-1)/2), vals.length-1].forEach((i,k)=>{
      const t = s("text",{x:X(i),y:hgt-6,"text-anchor":k===0?"start":k===2?"end":"middle"});
      t.textContent = new Date(t0 + i*step).toLocaleDateString(undefined,{month:"short",day:"numeric"}); svg.append(t);
    });
  }
  const pts = vals.map((v,i)=>`${X(i).toFixed(1)},${Y(v).toFixed(1)}`);
  svg.append(s("path",{d:`M${X(0)},${Y(mn)} L${pts.join(" L")} L${X(vals.length-1)},${Y(mn)} Z`,fill}));
  svg.append(s("polyline",{points:pts.join(" "),fill:"none",stroke:color,"stroke-width":1.8,"stroke-linejoin":"round"}));
  for (const o of overlays){
    if (o.v == null || !isFinite(o.v) || o.v < mn || o.v > mx) continue;
    const y = Y(o.v);
    svg.append(s("line",{x1:L,x2:w-R,y1:y,y2:y,stroke:o.color,"stroke-width":1.2,"stroke-dasharray":"4 3"}));
    const t = s("text",{x:L+4,y:y-4,style:`fill:${o.color}`}); t.textContent = o.label; svg.append(t);
  }
  const e = vals.length-1; svg.append(s("circle",{cx:X(e),cy:Y(vals[e]),r:3.5,fill:color}));
  return svg;
}
function gauge(val, label){
  const svg = s("svg",{viewBox:"0 0 200 120",role:"img","aria-label":`${label} ${val}`});
  const arc = (a0,a1,col,wd=14)=>{ const p=a=>[100+80*Math.cos(Math.PI*(1-a)),100-80*Math.sin(Math.PI*(1-a))]; const [x0,y0]=p(a0),[x1,y1]=p(a1);
    return s("path",{d:`M${x0},${y0} A80,80 0 0 1 ${x1},${y1}`,stroke:col,"stroke-width":wd,fill:"none"}); };
  svg.append(arc(0,.32,"var(--down-soft)"), arc(.32,.45,"var(--warn-soft)"), arc(.45,.62,"var(--neutral-soft)"), arc(.62,1,"var(--up-soft)"));
  if (val != null){
    const v = Math.max(0, Math.min(100, val))/100;
    const col = val>=62?"var(--up)":val>=45?"var(--ink-2)":val>=32?"var(--warn)":"var(--down)";
    svg.append(arc(0, Math.max(v,.005), col, 6));
    const a = Math.PI*(1-v); svg.append(s("circle",{cx:100+80*Math.cos(a),cy:100-80*Math.sin(a),r:6,fill:col}));
    const t = s("text",{x:100,y:96,"text-anchor":"middle",style:"font-size:34px;fill:var(--ink);font-family:var(--f-display);font-weight:700"}); t.textContent = val; svg.append(t);
  }
  const t2 = s("text",{x:100,y:116,"text-anchor":"middle"}); t2.textContent = label; svg.append(t2);
  return svg;
}

