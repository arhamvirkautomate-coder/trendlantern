#!/usr/bin/env python3
"""Assembles site/index.html from src/ (run after editing anything in src/)."""
import os
R = os.path.dirname(os.path.abspath(__file__))
rd = lambda n: open(os.path.join(R, n), encoding="utf-8").read()
HEAD = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>TrendLantern</title>
<meta name="description" content="Crypto research that grades itself in public. Every trend call is logged and scored 1, 3 and 7 days later. Plus trend scores for the top 40 coins, technical levels, news sentiment, Fear &amp; Greed and backtests, refreshed automatically every 4 hours. General information only.">
<meta property="og:title" content="TrendLantern">
<meta property="og:description" content="Crypto research that keeps its receipts: every trend call logged and graded in public. Updated every 4 hours.">
<meta property="og:type" content="website">
<meta name="theme-color" content="#15202b">
<link rel="icon" href="favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap">
<style>
:root{color-scheme:light}
[hidden]{display:none!important}
"""
html = HEAD + rd("style.css") + "\n</style>\n</head>\n<body>\n" + rd("body.html") + "\n<script>\n" + rd("app.js").replace("/*HELPERS*/", rd("helpers.js")) + "\n</script>\n</body>\n</html>\n"
out = os.path.join(R, "..", "site", "index.html")
open(out, "w", encoding="utf-8").write(html)
print("wrote", os.path.normpath(out), len(html) // 1024, "KB")
