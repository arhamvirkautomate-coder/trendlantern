(() => {
"use strict";
// ------------------------------------------------------------ site settings (edit these)
const SITE = { contactEmail: "" };  // e.g. "hello@yourdomain.com"; shown in the footer when set

// ------------------------------------------------------------ state
const S = { snap:null, charts:null, news:null, brief:null, hist:null, ledger:null, cur:"USD", horizon:"short",
  sort:{k:"score",dir:-1}, newsCat:"All", chartMode:"h4", wl:{items:[], alerts:[]} };
const CUR = {USD:{s:"$"},EUR:{s:"€"},GBP:{s:"£"},AUD:{s:"A$"},CAD:{s:"C$"},PKR:{s:"Rs "},INR:{s:"₹"},AED:{s:"AED "}};
const $ = (s, r=document) => r.querySelector(s);
function h(tag, attrs, ...kids){
  const el = document.createElement(tag);
  if (attrs) for (const [k,v] of Object.entries(attrs)){
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const k of kids.flat()) if (k != null && k !== false) el.append(k instanceof Node ? k : String(k));
  return el;
}
const safeUrl = u => /^https?:\/\//i.test(u||"") ? u : null;
const store = { get(k, d){ try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch(e){ return d; } },
                set(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch(e){} } };
S.cur = store.get("tl_cur", "USD"); S.wl = store.get("tl_watch", {items:[], alerts:[]});

/*HELPERS*/

// ------------------------------------------------------------ routing
const VIEWS = ["overview","receipts","scanner","news","watchlist","backtest","tools","method"];
function route(){
  const v = VIEWS.includes(location.hash.slice(1)) ? location.hash.slice(1) : "overview";
  for (const id of VIEWS) $("#v-"+id).hidden = id !== v;
  for (const a of document.querySelectorAll("#tabs a")) a.setAttribute("aria-current", a.getAttribute("href")==="#"+v ? "page" : "false");
}
addEventListener("hashchange", () => { route(); scrollTo(0,0); });

// ------------------------------------------------------------ header
function renderHeader(){
  const m = S.snap?.meta;
  $("#updated").textContent = m ? `Updated ${ago(m.generated_ms)}` : "Loading…";
  $("#pulse").classList.toggle("stale", !m || Date.now() - m.generated_ms > 9*3600e3);
  const sel = $("#curSel");
  if (S.snap && sel.options.length !== Object.keys(S.snap.fx).length){
    sel.replaceChildren(...Object.keys(S.snap.fx).filter(c => CUR[c]).map(c => h("option",{value:c},c)));
  }
  if (S.snap && !S.snap.fx[S.cur]) S.cur = "USD";
  sel.value = S.cur;
  const bn = $("#banners"); bn.replaceChildren();
  if (m && Date.now() - m.generated_ms > 9*3600e3) bn.append(h("div",{class:"banner err"}, h("span",null,`The last update was ${ago(m.generated_ms)}. Prices below may be out of date.`)));
}

// ------------------------------------------------------------ overview
function levelBoxes(c, hz){
  if (hz === "short"){ const L = c.short.levels;
    return h("div",{class:"levels"}, h("div",null,"Pullback zone", h("b",null, fp(L.pullback[0]))), h("div",null,"Volatility stop", h("b",{class:"down"}, fp(L.vstop))), h("div",null,"Resistance", h("b",null, fp(L.resistance)))); }
  const L = c.long.levels;
  return h("div",{class:"levels"}, h("div",null,"50/200-day band", h("b",null, fp(L.band[0]))), h("div",null,"Trend break", h("b",{class:"down"}, fp(L.trend_break))), h("div",null,"1-year high", h("b",null, fp(L.hi1y))));
}
function renderOverview(){
  const sn = S.snap; if (!sn) return;
  const mk = sn.market;
  $("#gauge").replaceChildren(gauge(mk.score, "market score / 100"));
  $("#stanceTitle").textContent = mk.stance;
  $("#stanceText").textContent = mk.regime?.text || "";
  const k = $("#kpis"); k.replaceChildren();
  const kpi = (label, v, sub, sc) => h("div",{class:"kpi"}, h("span",{class:"eyebrow"},label), h("span",{class:"v"},v), h("span",{class:"s "+(sc||"muted")},sub));
  const btc = coin("BTC"), eth = coin("ETH");
  if (btc) k.append(kpi("Bitcoin", fp(btc.price), `${fpct(btc.ch24h)} 24h · ${fpct(btc.ch7d)} 7d`, cls(btc.ch24h)));
  if (eth) k.append(kpi("Ethereum", fp(eth.price), `${fpct(eth.ch24h)} 24h · ${fpct(eth.ch7d)} 7d`, cls(eth.ch24h)));
  k.append(kpi("Total market cap", fb(mk.total_mcap), fpct(mk.mcap_ch24)+" 24h", cls(mk.mcap_ch24)));
  k.append(kpi("Fear & Greed", mk.fng?.v ?? "—", mk.fng?.l || ""));
  k.append(kpi("BTC dominance", mk.btc_dom ? mk.btc_dom.toFixed(1)+"%" : "—", `ETH ${mk.eth_dom?.toFixed?.(1) ?? "—"}%`));
  k.append(kpi("Market breadth", mk.breadth?.st != null ? mk.breadth.st+"%" : "—", `above 4h trend · ${mk.breadth?.lt ?? "—"}% above 200d`));
  if (mk.stables) k.append(kpi("Stablecoin supply", fb(mk.stables.total), fpct(mk.stables.ch30,1)+" in 30 days", cls(mk.stables.ch30)));
  if (mk.tvl) k.append(kpi("DeFi TVL", fb(mk.tvl.total), fpct(mk.tvl.ch30,1)+" in 30 days", cls(mk.tvl.ch30)));
  const mv = $("#movers"); mv.replaceChildren();
  const list = (title, arr) => h("div",null, h("div",{class:"eyebrow"},title), ...arr.map(x => h("button",{type:"button",class:"spread linkrow",onclick:()=>openCoin(x.sym)}, h("b",{style:"font-family:var(--f-display)"},x.sym), h("span",{class:"num "+cls(x.ch)}, fpct(x.ch)))));
  mv.append(list("Top gainers", mk.gainers||[]), list("Top losers", mk.losers||[]));
  $("#fngChart").replaceChildren(lineChart(mk.fng?.hist||[], {hgt:120, fmt:v=>Math.round(v), yMin:0, yMax:100, color:"var(--accent)", fill:"transparent",
    overlays:[{v:25,label:"extreme fear",color:"var(--up)"},{v:75,label:"extreme greed",color:"var(--down)"}]}));
  const card = (c, hz) => h("button",{class:"pick",type:"button",onclick:()=>openCoin(c.sym)},
    h("div",{class:"spread"}, h("span",{class:"sym"},c.sym), h("span",{class:"row",style:"gap:6px"}, pill(c[hz].label), h("span",{class:"score"},c[hz].score))),
    h("div",{class:"spread",style:"font-size:.85rem"}, h("span",{class:"num"},fp(c.price)), h("span",{class:"num "+cls(c.ch7d)},fpct(c.ch7d)+" 7d"), c.meme ? h("span",{class:"pill meme"},"meme") : riskPill(c.risk)),
    levelBoxes(c, hz),
    c.bt?.n ? h("div",{class:"faint",style:"font-size:.8rem"}, `Backtest: ${c.bt.n} trades, ${c.bt.win}% winners`) : null);
  const fill = (id, syms, hz, empty) => { const el = $(id); el.replaceChildren(); const cs = syms.map(coin).filter(Boolean);
    if (!cs.length) el.append(h("div",{class:"empty"}, empty)); else cs.forEach(c => el.append(card(c, hz))); };
  fill("#leadShort", sn.leaders.short, "short", "No coin has a clear short-term uptrend right now.");
  fill("#leadLong", sn.leaders.long, "long", "No coin has a clear long-term uptrend right now.");
  const chips = (id, syms, emptyText) => { const el = $(id); el.replaceChildren(); if (!syms.length) el.append(h("span",{class:"faint"},emptyText));
    syms.forEach(sy => { const c = coin(sy); el.append(h("button",{class:"chip",type:"button",onclick:()=>openCoin(sy)}, sy, c ? " "+fpct(c.ch7d,1) : "")); }); };
  chips("#leadWeak", sn.leaders.weak, "No coin is in a clear downtrend on both timeframes.");
  chips("#leadMeme", sn.leaders.meme, "No meme coins tracked right now.");
  renderMyAlerts();
}
function renderBrief(){
  const b = S.brief, body = $("#briefBody");
  if (!b) return;
  $("#briefTime").textContent = "written " + ago(b.generated_ms);
  body.replaceChildren();
  if (b.headline) body.append(h("p",null, h("strong",null,b.headline)));
  if (b.summary) String(b.summary).split(/\n\n+/).forEach(p => body.append(h("p",null,p)));
  const sec = (title, arr) => { if (!arr?.length) return; body.append(h("div",{class:"eyebrow",style:"margin-top:10px"},title), h("ul",null, ...arr.map(x => h("li",null, typeof x === "string" ? x : [h("strong",null,(x.title||"")+". "), x.detail||""])))); };
  sec("Key events", b.events);
  if (b.short_outlook) body.append(h("div",{class:"eyebrow",style:"margin-top:10px"},"Next few days"), h("p",null,b.short_outlook));
  if (b.long_outlook) body.append(h("div",{class:"eyebrow",style:"margin-top:10px"},"Longer term"), h("p",null,b.long_outlook));
  sec("Risks to watch", b.risks);
  sec("Upcoming dates", b.calendar);
  body.append(h("p",{class:"faint",style:"font-size:.78rem;margin-top:10px"},"Written by an AI model from the data on this page. It can make mistakes and is not advice."));
}
function renderHistory(){
  const pts = (S.hist?.points||[]).filter(p => p.score != null);
  $("#histWrap").hidden = pts.length < 3;
  if (pts.length < 3) return;
  $("#histChart").replaceChildren(lineChart(pts.map(p=>p.score), {hgt:110, fmt:v=>Math.round(v), yMin:0, yMax:100, t0:pts[0].t, step:(pts[pts.length-1].t-pts[0].t)/(pts.length-1)}));
}
function renderMyAlerts(){
  const el = $("#myAlerts"); el.replaceChildren();
  if (!S.snap) return;
  const hits = S.wl.alerts.filter(a => { const c = coin(a.sym); return c && (a.dir==="above" ? c.price >= a.price : c.price <= a.price); });
  if (hits.length) el.append(h("div",{class:"spread"},h("h3",null,"Your price alerts"), h("a",{href:"#watchlist",style:"font-size:.85rem"},"Manage")),
    ...hits.map(a => h("div",{class:"alert-item hot"}, h("strong",null,`${a.sym} ${a.dir==="above"?"is above":"is below"} ${fp(a.price)}`), h("span",{class:"muted"},` · now ${fp(coin(a.sym).price)}`))));
}

// ------------------------------------------------------------ scanner
function renderScanner(){
  if (!S.snap) return;
  const hz = S.horizon, q = $("#q").value.trim().toUpperCase(), fl = $("#fLabel").value, fr = $("#fRisk").value, fmeme = $("#fMeme").checked;
  for (const b of document.querySelectorAll("#horizonSeg button")) b.setAttribute("aria-pressed", b.dataset.h === hz);
  let rows = S.snap.coins.filter(c => (!q || c.sym.includes(q) || (c.name||"").toUpperCase().includes(q)) && (!fl || c[hz].label === fl) && (!fr || c.risk === fr) && (fmeme || !c.meme));
  const key = {score:c=>c[hz].score, rank:c=>c.rank||999, price:c=>c.price, ch24h:c=>c.ch24h, ch7d:c=>c.ch7d, ch30d:c=>c.ch30d, risk:c=>["Low","Medium","High","Extreme"].indexOf(c.risk)}[S.sort.k];
  rows.sort((a,b) => (key(a)-key(b))*S.sort.dir);
  const cols = [["rank","#"],["coin","Coin"],["price","Price"],["ch24h","24h"],["ch7d","7d"],["ch30d","30d"],["spark","14 days"],["score","Trend"],["risk","Risk"],["lv", hz==="short"?"Support / Resistance":"200-day avg / 1y high"]];
  const thr = h("tr");
  for (const [k,l] of cols){ const sortable = !["coin","spark","lv"].includes(k);
    thr.append(h("th",{class:["price","ch24h","ch7d","ch30d"].includes(k)?"num":"", "aria-sort": S.sort.k===k ? (S.sort.dir>0?"ascending":"descending") : null},
      sortable ? h("button",{type:"button",onclick:()=>{ S.sort = {k, dir: S.sort.k===k ? -S.sort.dir : (k==="rank"||k==="risk"?1:-1)}; renderScanner(); }}, l + (S.sort.k===k ? (S.sort.dir>0?" ▲":" ▼") : "")) : l)); }
  $("#sigTable thead").replaceChildren(thr);
  const tb = $("#sigTable tbody"); tb.replaceChildren();
  for (const c of rows){
    const sg = c[hz], ser = S.charts?.series?.[c.sym]?.h4;
    const barCol = sg.score>=60?"var(--up)":sg.score>=45?"var(--ink-3)":sg.score>=32?"var(--warn)":"var(--down)";
    tb.append(h("tr",{onclick:()=>openCoin(c.sym),tabindex:"0",onkeydown:e=>{if(e.key==="Enter")openCoin(c.sym);}},
      h("td",{class:"faint num"}, c.rank ?? "—"),
      h("td",null, h("div",{class:"coincell"}, h("b",null,c.sym), c.name && c.name !== c.sym ? h("span",{class:"faint hidden-sm",style:"font-size:.8rem"},c.name) : null, c.meme ? h("span",{class:"pill meme"},"meme") : null)),
      h("td",{class:"num"}, fp(c.price)),
      h("td",{class:"num "+cls(c.ch24h)}, fpct(c.ch24h)), h("td",{class:"num "+cls(c.ch7d)}, fpct(c.ch7d)), h("td",{class:"num "+cls(c.ch30d)}, fpct(c.ch30d)),
      h("td",null, spark(ser)),
      h("td",null, h("div",{class:"row",style:"gap:8px;flex-wrap:nowrap"}, pill(sg.label), h("span",{class:"score"},sg.score), h("div",{class:"bar"}, h("i",{style:`width:${sg.score}%;background:${barCol}`})))),
      h("td",null, riskPill(c.risk)),
      h("td",{class:"num",style:"font-size:.82rem"}, hz==="short" ? `${fp(c.ind.support)} / ${fp(c.ind.resistance)}` : `${fp(c.ind.ema200_1d)} / ${fp(c.ind.hi365)}`)));
  }
  if (!rows.length) tb.append(h("tr",null,h("td",{colspan:cols.length,class:"faint"},"No coins match these filters.")));
  $("#sigCount").textContent = `${rows.length} of ${S.snap.coins.length} coins`;
}

// ------------------------------------------------------------ coin sheet
let lastFocus = null;
function btCard(c){
  const b = c.bt; if (!b) return null;
  const head = h("div",{class:"spread"}, h("h3",null,"Backtest of the short-term model on "+c.sym), h("span",{class:"faint",style:"font-size:.8rem"},`last ${b.days} days · no news`));
  if (!b.n) return h("div",{class:"card",style:"margin-top:12px"}, head, h("p",{class:"muted",style:"margin:8px 0 0"},`The model produced no Strong uptrend entries on ${c.sym} in this period. Buy and hold: ${fpct(b.hold,1)}.`));
  const t = (l,v,cl) => h("div",null,l,h("b",{class:cl||""},v));
  return h("div",{class:"card",style:"margin-top:12px"}, head,
    h("div",{class:"levels",style:"margin-top:10px"}, t("Trades", b.n), t("Winners", b.win+"%"), t("Avg per trade", fpct(b.avg), cls(b.avg)),
      t("Profit factor", b.pf ?? "∞", b.pf==null||b.pf>=1?"up":"down"), t("Model account", fpct(b.acct,1), cls(b.acct)), t("Buy & hold", fpct(b.hold,1), cls(b.hold))),
    h("p",{class:"faint",style:"margin:10px 0 0;font-size:.82rem"}, "Past results do not predict future results. See the Backtests tab for the method."));
}
function openCoin(sym){
  const c = coin(sym); if (!c) return;
  lastFocus = document.activeElement;
  const sh = $("#sheet"); sh.replaceChildren();
  const series = S.charts?.series?.[sym], st = c.short, lt = c.long, note = S.brief?.coin_notes?.[sym];
  const chartBox = h("div",{class:"chartbox"});
  const drawChart = () => {
    const mode = S.chartMode, vals = series?.[mode] || [];
    const ov = mode === "h4"
      ? [{v:st.levels.vstop,label:"volatility stop",color:"var(--down)"},{v:st.levels.r15,label:"+1.5R",color:"var(--up)"},{v:st.levels.r3,label:"+3R",color:"var(--up)"}]
      : [{v:c.ind.ema200_1d,label:"200-day avg",color:"var(--accent)"},{v:lt.levels.trend_break,label:"trend break",color:"var(--down)"}];
    chartBox.replaceChildren(lineChart(vals, {overlays:ov, t0: mode==="h4"?series?.t4:series?.td, step: mode==="h4"?4*3600e3:86400e3}));
    for (const b of sh.querySelectorAll("[data-cm]")) b.setAttribute("aria-pressed", b.dataset.cm === mode);
  };
  const reasons = arr => h("ul",{class:"reasons"}, ...arr.map(r => h("li",null, h("span",{class:"m "+(r.s>0?"up":r.s<0?"down":"faint")}, r.s>0?"+":r.s<0?"−":"·"), h("span",null,r.t))));
  const newsFor = (S.news?.items||[]).filter(n => n.coins?.includes(sym)).slice(0,6);
  const L = st.levels, LL = lt.levels;
  sh.append(...[
    h("div",{class:"head"},
      h("div",null, h("div",{class:"eyebrow"}, `#${c.rank ?? "—"} · ${c.name||c.sym}`), h("h2",{id:"sheetTitle",style:"font-size:1.8rem"}, c.sym),
        h("div",{class:"row",style:"margin-top:4px"}, h("span",{class:"price"},fp(c.price)), h("span",{class:"num "+cls(c.ch24h)},fpct(c.ch24h)+" 24h"), h("span",{class:"num "+cls(c.ch7d)},fpct(c.ch7d)+" 7d"), c.meme ? h("span",{class:"pill meme"},"meme coin") : null, riskPill(c.risk))),
      h("button",{class:"btn",type:"button",onclick:closeSheet,"aria-label":"Close"},"Close")),
    h("div",{class:"card"},
      h("div",{class:"spread"}, h("div",{class:"seg",role:"group","aria-label":"Chart range"},
        h("button",{type:"button","data-cm":"h4",onclick:()=>{S.chartMode="h4";drawChart();}},"14 days · 4h"),
        h("button",{type:"button","data-cm":"d1",onclick:()=>{S.chartMode="d1";drawChart();}},"4 months · daily")),
        h("span",{class:"faint",style:"font-size:.8rem"},"Dashed lines: technical reference levels")),
      h("div",{style:"margin-top:8px"}, chartBox)),
    note ? h("div",{class:"card",style:"margin-top:12px"}, h("div",{class:"eyebrow"},"AI note"), h("p",{style:"margin:6px 0 0"},note)) : null,
    h("div",{class:"grid g2",style:"margin-top:12px"},
      h("div",{class:"card"},
        h("div",{class:"spread"}, h("h3",null,"Short-term trend"), h("span",{class:"row",style:"gap:6px"}, pill(st.label), h("span",{class:"score"},st.score+"/100"))),
        h("div",{class:"levels",style:"margin-top:10px"},
          h("div",null,"Pullback zone", h("b",null, `${fp(L.pullback[0])} – ${fp(L.pullback[1])}`)),
          h("div",null,"Volatility stop", h("b",{class:"down"}, `${fp(L.vstop)} (−${L.vstop_pct}%)`)),
          h("div",null,"Resistance", h("b",null, fp(L.resistance))),
          h("div",null,"+1.5R level", h("b",{class:"up"}, `${fp(L.r15)} (+${L.r15_pct}%)`)),
          h("div",null,"+3R level", h("b",{class:"up"}, `${fp(L.r3)} (+${L.r3_pct}%)`)),
          h("div",null,"4h ATR", h("b",null, c.ind.atr4h_pct+"%"))),
        h("p",{class:"faint",style:"font-size:.8rem;margin:8px 0 0"},"Reference levels used by the scoring model and backtest (2×ATR below price, then 1.5 and 3 times that distance above). They are not instructions."),
        h("div",{class:"eyebrow",style:"margin-top:12px"},"What drives the score"), reasons(st.reasons)),
      h("div",{class:"card"},
        h("div",{class:"spread"}, h("h3",null,"Long-term trend"), h("span",{class:"row",style:"gap:6px"}, pill(lt.label), h("span",{class:"score"},lt.score+"/100"))),
        h("div",{class:"levels",style:"margin-top:10px"},
          h("div",null,"50/200-day band", h("b",null, `${fp(LL.band[0])} – ${fp(LL.band[1])}`)),
          h("div",null,"Trend break", h("b",{class:"down"}, fp(LL.trend_break))),
          h("div",null,"1-year high", h("b",null, fp(LL.hi1y)))),
        h("p",{class:"faint",style:"font-size:.8rem;margin:8px 0 0"},"Trend break = 8% below the 200-day average, where the long-term uptrend would be considered broken."),
        h("div",{class:"eyebrow",style:"margin-top:12px"},"What drives the score"), reasons(lt.reasons))),
    btCard(c),
    h("h3",{style:"margin:16px 0 8px"},"Indicators"),
    h("div",{class:"inds"},
      ...[["RSI 4h",c.ind.rsi4h],["RSI daily",c.ind.rsi1d],["MACD 4h",c.ind.macd_rising?"rising":"falling"],["Volume vs avg","x"+c.ind.vol_ratio],
          ["Support",fp(c.ind.support)],["Resistance",fp(c.ind.resistance)],["200-day avg",fp(c.ind.ema200_1d)],["From 1y high",fpct(c.ind.dd365,1)],
          ["vs BTC, 90d",fpct(c.ind.rs_btc90,1)],["Volatility (yr)",c.ind.vol_ann+"%"],["Market cap",fb(c.mcap)],["24h volume",fb(c.vol24)]]
        .map(([k,v]) => h("div",null,k,h("b",null,v)))),
    h("h3",{style:"margin:16px 0 8px"},"Related news"),
    newsFor.length ? h("div",{class:"card"}, newsList(newsFor)) : h("p",{class:"faint"},"No headlines mention this coin in the latest update."),
    h("div",{class:"row",style:"margin-top:16px"},
      h("button",{class:"btn",type:"button",onclick:()=>{ addWatch(sym); closeSheet(); location.hash="#watchlist"; }}, S.wl.items.some(i=>i.sym===sym) ? "In your watchlist" : "Add to watchlist"))
  ].filter(Boolean));
  drawChart();
  $("#sheetBg").hidden = false; sh.hidden = false; sh.scrollTop = 0; sh.querySelector("button")?.focus();
}
function closeSheet(){ $("#sheet").hidden = true; $("#sheetBg").hidden = true; lastFocus?.focus?.(); }
$("#sheetBg").addEventListener("click", closeSheet);
addEventListener("keydown", e => { if (e.key === "Escape" && !$("#sheet").hidden) closeSheet(); });

// ------------------------------------------------------------ news
function newsList(items){
  return h("div",{class:"news"}, ...items.map(n => {
    const url = safeUrl(n.link);
    return h("article",{class: n.sent>0.15?"pos":n.sent<-0.15?"neg":""}, h("span",{class:"stripe"}),
      h("div",{style:"min-width:0"},
        url ? h("a",{class:"t",href:url,target:"_blank",rel:"noopener noreferrer nofollow"}, n.title) : h("span",{class:"t"},n.title),
        h("div",{class:"meta"}, h("span",null,n.source), h("span",null,ago(n.ts*1000)), h("span",{class:"pill"},n.cat),
          n.impact==="high" ? h("span",{class:"pill r"},"high impact") : null,
          h("span",{class:"pill "+(n.sent>0.15?"b":n.sent<-0.15?"s":"h")}, n.sent>0.15?"positive":n.sent<-0.15?"negative":"neutral"),
          ...(n.coins||[]).slice(0,5).map(sy => h("button",{class:"chip",type:"button",style:"padding:1px 7px",onclick:()=>openCoin(sy)},sy)))));
  }));
}
function renderNews(){
  const items = S.news?.items || [];
  const cats = ["All", ...new Set(items.map(n => n.cat))];
  $("#newsFilters").replaceChildren(...cats.map(ct => h("button",{class:"chip",type:"button","aria-pressed":S.newsCat===ct,onclick:()=>{S.newsCat=ct;renderNews();}},ct)),
    h("button",{class:"chip",type:"button","aria-pressed":S.newsCat==="__high",onclick:()=>{S.newsCat="__high";renderNews();}},"High impact only"));
  const shown = items.filter(n => S.newsCat==="All" || (S.newsCat==="__high" ? n.impact==="high" : n.cat===S.newsCat));
  $("#newsList").replaceChildren(shown.length ? newsList(shown) : h("div",{class:"empty"}, items.length ? "No headlines in this category." : "Loading headlines…"));
  const mood = S.snap?.market?.news_mood;
  $("#newsCount").textContent = `${shown.length} headlines` + (mood!=null ? ` · overall mood ${mood>0.1?"positive":mood<-0.1?"negative":"mixed"}` : "");
}

// ------------------------------------------------------------ watchlist (browser only)
function saveWl(){ store.set("tl_watch", S.wl); renderWatchlist(); renderMyAlerts(); }
function addWatch(sym, qty, cost){ if (!S.wl.items.some(i => i.sym === sym)) S.wl.items.push({sym, qty: qty||null, cost: cost||null}); saveWl(); }
function fillCoinSelects(){
  const opts = (S.snap?.coins||[]).map(c => h("option",{value:c.sym}, `${c.sym}${c.name && c.name!==c.sym ? " · "+c.name : ""}`));
  for (const id of ["#wSym","#aSym"]){ const el = $(id), v = el.value; el.replaceChildren(...opts.map(o => o.cloneNode(true))); if (v) el.value = v; }
}
function renderWatchlist(){
  const tb = $("#wlTable tbody"); tb.replaceChildren();
  let val = 0, cost = 0;
  S.wl.items.forEach((it, i) => {
    const c = coin(it.sym), v = c && it.qty ? it.qty*c.price : null, cs = it.qty && it.cost ? it.qty*it.cost : null, g = v!=null && cs!=null ? v-cs : null;
    if (v) val += v; if (cs) cost += cs;
    tb.append(h("tr",{onclick:e=>{ if(!e.target.closest("button")) openCoin(it.sym); }},
      h("td",null, h("b",{style:"font-family:var(--f-display)"},it.sym)), h("td",{class:"num"}, c?fp(c.price):"—"),
      h("td",{class:"num "+cls(c?.ch24h)}, c?fpct(c.ch24h):"—"), h("td",{class:"num "+cls(c?.ch7d)}, c?fpct(c.ch7d):"—"),
      h("td",null, c?pill(c.short.label):"—"), h("td",null, c?pill(c.long.label):"—"),
      h("td",{class:"num"}, v!=null?fm(v):"—"), h("td",{class:"num "+cls(g)}, g!=null?`${fm(g)} (${fpct(g/cs*100,1)})`:"—"),
      h("td",null, h("button",{class:"btn small",type:"button",onclick:()=>{ S.wl.items.splice(i,1); saveWl(); }},"Remove"))));
  });
  if (!S.wl.items.length) tb.append(h("tr",null,h("td",{colspan:9,class:"faint",style:"white-space:normal"},"Add coins you follow to see their trend status in one place. Add the amount and cost if you want to track value.")));
  $("#wlKpis").replaceChildren(
    h("div",{class:"kpi"},h("span",{class:"eyebrow"},"Coins watched"),h("span",{class:"v"},S.wl.items.length),h("span",{class:"s muted"},"saved in this browser")),
    h("div",{class:"kpi"},h("span",{class:"eyebrow"},"Tracked value"),h("span",{class:"v"},fm(val)),h("span",{class:"s muted"},"coins with an amount")),
    h("div",{class:"kpi"},h("span",{class:"eyebrow"},"Gain / loss"),h("span",{class:"v "+cls(val-cost)},cost?fm(val-cost):"—"),h("span",{class:"s "+cls(val-cost)},cost?fpct((val-cost)/cost*100,1):"add costs to see this")));
  const al = $("#alertList"); al.replaceChildren();
  S.wl.alerts.forEach((a, i) => { const c = coin(a.sym), hit = c && (a.dir==="above" ? c.price>=a.price : c.price<=a.price);
    al.append(h("div",{class:"alert-item"+(hit?" hot":"")}, h("span",{style:"flex:1"}, `${a.sym} ${a.dir==="above"?"rises above":"falls below"} ${fp(a.price)}`, h("span",{class:"faint"}, c ? ` · now ${fp(c.price)}` : ""), hit ? h("strong",null," · reached") : ""),
      h("button",{class:"btn small",type:"button",onclick:()=>{ S.wl.alerts.splice(i,1); saveWl(); }},"Remove"))); });
  if (!S.wl.alerts.length) al.append(h("span",{class:"faint",style:"font-size:.85rem"},"No alerts yet."));
}
$("#addWatch").addEventListener("submit", e => { e.preventDefault(); addWatch($("#wSym").value, +$("#wQty").value || null, +$("#wCost").value || null); e.target.reset(); });
$("#addAlert").addEventListener("submit", e => { e.preventDefault(); const p = +$("#aPrice").value; if (!(p>0)) return; S.wl.alerts.push({sym:$("#aSym").value, dir:$("#aDir").value, price:p}); $("#aPrice").value=""; saveWl(); });

// ------------------------------------------------------------ backtest
function renderBacktest(){
  const bt = S.snap?.backtest, k = $("#btKpis");
  if (!bt || !bt.trades){ k.replaceChildren(h("div",{class:"empty",style:"grid-column:1/-1"},"Backtest results appear after the next update.")); return; }
  $("#btNote").textContent = `${bt.coins} coins · last ${bt.days} days`;
  const t = (l,v,sub,cl) => h("div",{class:"kpi"},h("span",{class:"eyebrow"},l),h("span",{class:"v "+(cl||"")},v),h("span",{class:"s muted"},sub));
  k.replaceChildren(t("Simulated trades", bt.trades, "all coins"), t("Winners", bt.win+"%", "any profit after fees"),
    t("Avg per trade", fpct(bt.avg), "after 0.1% fees each way", cls(bt.avg)), t("Avg R", bt.avg_r, "result in units of risk", cls(bt.avg_r)),
    t("Beat buy & hold", `${bt.beat_hold} of ${bt.coins}`, "coins, at equal size"));
  $("#btVerdict").textContent = (bt.avg > 0.5 ? "Over this period the model had a small positive average result per trade" : bt.avg > 0 ? "Over this period the model roughly broke even per trade" : "Over this period the model lost money on average")
    + `, and it trailed simply holding on most coins. Results differ a lot between coins.`;
  const rows = S.snap.coins.filter(c => c.bt?.n).sort((a,b) => b.bt.acct - a.bt.acct);
  $("#btTable tbody").replaceChildren(...rows.map(c => h("tr",{onclick:()=>openCoin(c.sym)}, h("td",null,h("b",null,c.sym)), h("td",{class:"num"},c.bt.n), h("td",{class:"num"},c.bt.win+"%"),
    h("td",{class:"num "+cls(c.bt.avg)},fpct(c.bt.avg)), h("td",{class:"num "+(c.bt.pf==null||c.bt.pf>=1?"up":"down")},c.bt.pf ?? "∞"), h("td",{class:"num "+cls(c.bt.acct)},fpct(c.bt.acct,1)), h("td",{class:"num "+cls(c.bt.hold)},fpct(c.bt.hold,1)))));
}

// ------------------------------------------------------------ report card
function renderLedger(){
  const L = S.ledger, k = $("#ledKpis");
  if (!L){ k.replaceChildren(h("div",{class:"empty",style:"grid-column:1/-1"},"The report card starts with the next update.")); return; }
  const st = L.stats || {}, all = st.all || {n:0}, up = st.up || {n:0}, dn = st.down || {n:0};
  $("#ledNote").textContent = `logging since ${new Date(L.started_ms).toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"})} · ${st.total||0} calls`;
  const t = (l,v,sub,cl) => h("div",{class:"kpi"},h("span",{class:"eyebrow"},l),h("span",{class:"v "+(cl||"")},v),h("span",{class:"s muted"},sub));
  k.replaceChildren(
    t("Calls graded", all.n, `${st.open||0} still open`),
    t("Right after 7 days", all.n ? all.pct+"%" : "—", all.n ? `${all.right} of ${all.n} calls` : "first grades after 7 days", all.n ? (all.pct>=50?"up":"down") : ""),
    t("Uptrend calls", up.n ? `${up.pct}% right` : "—", up.n ? `avg 7d move ${fpct(up.avg7)} · vs BTC ${fpct(up.vs_btc)}` : "none graded yet", up.n ? cls(up.vs_btc) : ""),
    t("Downtrend calls", dn.n ? `${dn.pct}% right` : "—", dn.n ? `avg 7d move ${fpct(dn.avg7)}` : "none graded yet", dn.n ? (dn.pct>=50?"up":"down") : ""));
  const date = ms => new Date(ms).toLocaleDateString(undefined,{day:"numeric",month:"short"}) + " " + new Date(ms).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
  const lab = d => h("span",{class:"pill "+(d==="up"?"sb":"s")}, d==="up"?"Strong uptrend":"Downtrend");
  const calls = (L.calls||[]).slice().sort((a,b) => b.t - a.t);
  const open = calls.filter(c => !c.graded), done = calls.filter(c => c.graded);
  $("#ledOpen tbody").replaceChildren(...(open.length ? open.map(c => { const now = coin(c.sym)?.price, mv = now ? (now/c.price-1)*100 : null;
    return h("tr",{onclick:()=>openCoin(c.sym)}, h("td",null,date(c.t)), h("td",null,h("b",null,c.sym)), h("td",null,lab(c.dir)), h("td",{class:"num"},fp(c.price)), h("td",{class:"num"},now?fp(now):"—"),
      h("td",{class:"num "+cls(mv)}, mv==null?"—":fpct(mv)), h("td",{class:"num faint"}, new Date(c.t+7*864e5).toLocaleDateString(undefined,{day:"numeric",month:"short"}))); })
    : [h("tr",null,h("td",{colspan:7,class:"faint"},"No open calls."))]));
  const cell = v => h("td",{class:"num "+cls(v)}, v==null?"n/a":fpct(v,1));
  $("#ledDone tbody").replaceChildren(...(done.length ? done.map(c => h("tr",{onclick:()=>openCoin(c.sym)},
      h("td",null,date(c.t)), h("td",null,h("b",null,c.sym)), h("td",null,lab(c.dir)), h("td",{class:"num"},fp(c.price)), cell(c.d1), cell(c.d3), cell(c.d7),
      h("td",{class:"num "+cls(c.d7!=null&&c.d7_btc!=null?c.d7-c.d7_btc:null)}, c.d7!=null&&c.d7_btc!=null ? fpct(c.d7-c.d7_btc,1) : "—"),
      h("td",null, c.right==null ? h("span",{class:"faint"},"no data") : c.right ? h("span",{class:"pill b"},"✓ right") : h("span",{class:"pill s"},"✗ wrong"))))
    : [h("tr",null,h("td",{colspan:9,class:"faint",style:"white-space:normal"},"No graded calls yet. Each call is graded 7 days after it is logged."))]));
  const g = all.n ? `So far ${all.right} of ${all.n} graded calls were right after 7 days (${all.pct}%).` : `${st.total||0} calls logged so far. The first grades arrive 7 days after the first call.`;
  $("#receiptLine").textContent = g + " Wrong calls stay on the record.";
}

// ------------------------------------------------------------ calculator
function renderCalc(){
  const cap=+$("#cCap").value, r=+$("#cRisk").value/100, en=+$("#cEntry").value, stp=+$("#cStop").value, tp=+$("#cTp").value, out = $("#cOut");
  if (!(cap>0 && en>0 && stp>0 && stp<en)){ out.replaceChildren(h("span",{class:"faint"},"Enter an entry price above the stop price.")); return; }
  const sp = (en-stp)/en, size = Math.min(cap*r/sp, cap), qty = size/en, fees = size*0.001*2, rr = tp>en ? (tp-en)/(en-stp) : null;
  const t = (l,v,s,c) => h("div",{class:"kpi"},h("span",{class:"eyebrow"},l),h("span",{class:"v "+(c||"")},v),h("span",{class:"s muted"},s));
  out.replaceChildren(t("Position size","$"+size.toFixed(2), `${(size/cap*100).toFixed(0)}% of account`), t("Units", Number(qty.toPrecision(5)).toString(), `at $${en}`),
    t("Loss if stop is hit","$"+(size*sp+fees).toFixed(2), `stop ${(sp*100).toFixed(1)}% away, plus fees`, "down"),
    t("Reward : risk", rr ? rr.toFixed(2)+" : 1" : "—", rr ? "target distance ÷ stop distance" : "set a target above entry"),
    t("Gain if target is hit", rr ? "$"+(qty*(tp-en)-fees).toFixed(2) : "—", "after 0.1% fees each way", "up"));
}
for (const id of ["#cCap","#cRisk","#cEntry","#cStop","#cTp"]) $(id).addEventListener("input", renderCalc);

// ------------------------------------------------------------ method
function renderMethod(){
  const m = S.snap?.meta, el = $("#srcList"); el.replaceChildren();
  if (!m){ el.append(h("li",{class:"faint"},"Loading…")); return; }
  (m.sources_ok||[]).forEach(x => el.append(h("li",null, h("span",{class:"up"},"✓ "), x)));
  (m.sources_failed||[]).forEach(x => el.append(h("li",null, h("span",{class:"down"},"✕ "), x)));
  el.append(h("li",{class:"faint"}, `Engine v${m.version} · ${m.coins} coins`));
}

// ------------------------------------------------------------ render + data loading
function renderAll(){
  renderHeader();
  if (S.snap){ fillCoinSelects(); renderOverview(); renderScanner(); renderBacktest(); }
  renderBrief(); renderNews(); renderWatchlist(); renderMethod(); renderHistory(); renderLedger();
}
$("#curSel").addEventListener("change", e => { S.cur = e.target.value; store.set("tl_cur", S.cur); renderAll(); });
$("#horizonSeg").addEventListener("click", e => { const b = e.target.closest("button"); if (!b) return; S.horizon = b.dataset.h; renderScanner(); });
for (const id of ["#q","#fLabel","#fRisk","#fMeme"]) $(id).addEventListener("input", renderScanner);

async function getJSON(name, v){ const r = await fetch(`data/${name}.json?v=${v}`, {cache:"no-store"}); if (!r.ok) throw new Error(name+" "+r.status); return r.json(); }
let loadedAt = 0;
async function load(){
  const v = Math.floor(Date.now()/300000);
  try {
    const snap = await getJSON("snapshot", v);
    if (snap.meta.generated_ms === loadedAt) return;
    const [charts, news, hist, brief, ledger] = await Promise.all(["charts","news","history","brief","ledger"].map(n => getJSON(n, v).catch(() => null)));
    Object.assign(S, {snap, charts, news, hist, brief, ledger}); loadedAt = snap.meta.generated_ms; renderAll();
  } catch(e){
    if (!S.snap) $("#banners").replaceChildren(h("div",{class:"banner err"}, h("span",null,"Market data couldn't be loaded. Check your connection and refresh the page.")));
  }
}

$("#yr").textContent = new Date().getFullYear();
if (SITE.contactEmail) $("#contactLine").append("Contact: ", h("span",{class:"mono"},SITE.contactEmail));
if (!store.get("tl_ack", false)) $("#notice").hidden = false;
$("#noticeOk").addEventListener("click", () => { store.set("tl_ack", true); $("#notice").hidden = true; });
route(); renderAll(); renderCalc(); load();
setInterval(load, 300000); setInterval(renderHeader, 60000);
})();
